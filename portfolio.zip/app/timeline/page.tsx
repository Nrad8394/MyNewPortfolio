"use client"

import { motion, useScroll, useTransform } from "framer-motion"
import { useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import Link from "next/link"
import type { TimelineItem } from "@/types"

const timelineItems: TimelineItem[] = [
  {
    id: "1",
    title: "Senior Full Stack Developer",
    subtitle: "Tech Solutions Inc.",
    date: "2021 - Present",
    description: "Leading development of enterprise web applications",
    type: "work",
    details: ["Managed team of 5 developers", "Improved application performance by 40%", "Implemented CI/CD pipeline"],
    technologies: ["React", "Node.js", "AWS", "TypeScript"],
    link: "https://example.com",
  },
  {
    id: "2",
    title: "Frontend Developer",
    subtitle: "Digital Innovations Ltd",
    date: "2019 - 2021",
    description: "Developed responsive web applications",
    type: "work",
    details: ["Built 10+ client projects", "Mentored junior developers", "Introduced TypeScript to the team"],
    technologies: ["React", "TypeScript", "Tailwind CSS"],
    link: "https://example.com",
  },
  {
    id: "3",
    title: "BSc in Computer Science",
    subtitle: "University of Technology",
    date: "2015 - 2019",
    description: "Graduated with First Class Honours",
    type: "education",
    details: ["President of Computing Society", "Best Final Year Project Award", "Research focus on Web Technologies"],
  },
]

export default function TimelinePage() {
  return (
    <main className="container py-12">
      <div className="space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">Timeline</h1>
          <p className="text-lg text-muted-foreground">My professional journey and educational background</p>
        </div>

        <div className="relative">
          <div className="absolute left-8 top-0 h-full w-px bg-border md:left-1/2" aria-hidden="true" />
          <div className="space-y-12">
            {timelineItems.map((item, index) => (
              <TimelineCard key={item.id} item={item} index={index} />
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

function TimelineCard({ item, index }: { item: TimelineItem; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "center center"],
  })

  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1])
  const x = useTransform(scrollYProgress, [0, 0.5], [index % 2 === 0 ? -50 : 50, 0])

  return (
    <motion.div
      ref={cardRef}
      style={{ opacity, x }}
      className={`relative grid gap-8 md:grid-cols-2 ${index % 2 === 0 ? "md:text-right" : "md:text-left"}`}
    >
      <div
        className={`flex items-center ${
          index % 2 === 0 ? "justify-end md:col-start-1" : "justify-start md:col-start-2"
        }`}
      >
        <Card className="w-full">
          <CardHeader>
            <CardTitle>{item.title}</CardTitle>
            <CardDescription>{item.subtitle}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{item.description}</p>
            <ul className="space-y-2 text-sm">
              {item.details.map((detail, i) => (
                <li key={i}>{detail}</li>
              ))}
            </ul>
            {item.technologies && (
              <div className="flex flex-wrap gap-2">
                {item.technologies.map((tech) => (
                  <Badge key={tech} variant="secondary">
                    {tech}
                  </Badge>
                ))}
              </div>
            )}
            {item.link && (
              <Button variant="outline" size="sm" asChild>
                <Link href={item.link} target="_blank" rel="noopener noreferrer">
                  Visit Website
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
      <div
        className={`flex items-center ${
          index % 2 === 0 ? "justify-start md:col-start-2" : "justify-end md:col-start-1"
        }`}
      >
        <div className="text-lg font-semibold">{item.date}</div>
      </div>
      <div
        className="absolute left-8 top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-primary bg-background md:left-1/2"
        aria-hidden="true"
      />
    </motion.div>
  )
}

