import { OpenAIStream, StreamingTextResponse } from "ai"
import { Configuration, OpenAIApi } from "openai-edge"

// Create an OpenAI API client (that's edge friendly!)
const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(config)

// IMPORTANT! Set the runtime to edge
export const runtime = "edge"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Ask OpenAI for a streaming chat completion
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      stream: true,
      messages: [
        {
          role: "system",
          content: `You are a helpful portfolio assistant. Help visitors navigate through my portfolio and answer questions about:
          - My skills and experience
          - Projects I've worked on
          - My background and education
          - How to contact me
          Be concise, friendly, and professional. If you're not sure about something, direct them to the contact form.`,
        },
        ...messages,
      ],
    })

    // Convert the response into a friendly text-stream
    const stream = OpenAIStream(response)

    // Return a StreamingTextResponse, which can be consumed by the client
    return new StreamingTextResponse(stream)
  } catch (error) {
    console.error("Chat API Error:", error)
    return new Response("An error occurred during the chat request.", { status: 500 })
  }
}

