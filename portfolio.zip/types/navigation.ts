export interface Route {
  href: string
  label: string
}

export interface NavigationProps {
  className?: string
}

