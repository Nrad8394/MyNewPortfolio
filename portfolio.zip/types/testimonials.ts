export interface Testimonial {
  name: string
  position: string
  quote: string
  image: string
}

